import type { Guitar } from '../types'

/*opción 1*/
type GuitarProps = {
    guitar: Guitar,
    addToCart: (item:Guitar) => void
};


/*void no retorna nada
opción 2:
export default function Guitar({guitar, addToCart} : {guitar: Guitar, addToCart: (item:Guitar) => void }){*/

export default function Guitar({guitar, addToCart} : GuitarProps){
    const { name, image, description, price} = guitar


    return(
        <div className="col-md-6 col-lg-4 my-4 row align-items-center">
                <div className="col-4">
                    <img className="img-fluid" src={`/img/${image}.jpg`} alt="imagen guitarra" />
                </div>
                <div className="col-8">
                    <h3 className="text-black fs-4 fw-bold text-uppercase">{name}</h3>
                    <p>{description}</p>
                    <p className="fw-black text-primary fs-3">${price}</p>
                    <button type="button" className="btn btn-dark w-100" 
                   onClick={() => addToCart(guitar)}
                    >Agregar al Carrito
                    </button>
                </div>
        </div>
    )

    /*
    1º forma: crear el const para introducir los elementos y luego en el html poner sólo el elemento
    2º forma: {guitar.name} directamente, sin necesidad de poner el const{elementos} = guitar  */
    
}